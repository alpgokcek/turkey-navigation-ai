# turkey-navigation-ai
Turkey map navigation AI

#### Author:     Alp Gökçek
#### Github:     alpgokcek
#### Email:      alp.gokcek1@gmail.com
#### Date:       December, 2020

Description:
    Turkey map navigation AI with Python

## Commands

#### Building the requirements
`pip install -r requirements.txt`

#### Running the app
`python3 main.py`

<br/>
Contact me through email if you have any questions...

Have a great day